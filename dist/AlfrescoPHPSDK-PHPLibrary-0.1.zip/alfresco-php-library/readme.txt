
== Alfresco PHP Libarary ==

Installation and developer documentation for the Alfresco PHP Library can be found on the Alfresco Wiki.

== Documentation Links ==

Installation Instructions - http://code.google.com/p/alfresco-php-sdk/wiki/AlfrescoPHPLibraryInstallationInstructions
MediaWiki Integration Installation Instructions - http://wiki.alfresco.com/wiki/Alfresco_MediaWiki_Installation_Instructions
PHP API Documentation - http://wiki.alfresco.com/wiki/Alfresco_PHP_API


